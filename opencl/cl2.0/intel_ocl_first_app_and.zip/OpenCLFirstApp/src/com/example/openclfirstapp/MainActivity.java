package com.example.openclfirstapp;

import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import android.os.Bundle;
import android.app.Activity;
import android.content.res.AssetManager;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {

	private static final int ARRAY_SIZE = 262144;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
	
	public void exitApp(View view)
	{
		finish();
	}
	
	public void calcVectors(View view)
	{
		int[] arrayA = new int[ARRAY_SIZE];
		int[] arrayB = new int[ARRAY_SIZE];
		int[] arrayC = new int[ARRAY_SIZE];
		float[] execTime = new float[1];
		execTime[0] = 0;

		AssetManager am = getAssets();

		try
		{
			initArrays(arrayA, arrayB, arrayC, ARRAY_SIZE);
			InputStream is = am.open("OpenCLFirstApp_kernel.cl");
			String kernelCode = convertInputStreamToString(is);
			
			addArraysViaOpenCL(arrayA,arrayB,arrayC, kernelCode, execTime);
		}
		catch(IOException e)
        {
        	Log.d("oclDebug",e.toString());
        }

		String print = String.valueOf(execTime[0]);
		print += " (ms)";
		TextView myTextField = (TextView)findViewById(R.id.tv1);
		myTextField.setText(print);
	}
	
	public void calcVectorsNative(View view)
	{
		int[] arrayA = new int[ARRAY_SIZE];
		int[] arrayB = new int[ARRAY_SIZE];
		int[] arrayC = new int[ARRAY_SIZE];

		long difference=0;

		initArrays(arrayA, arrayB, arrayC, ARRAY_SIZE);
		
		long startTime = System.currentTimeMillis();
		calcArrays(arrayA, arrayB, arrayC, ARRAY_SIZE);
		difference = System.currentTimeMillis() - startTime;

		String print = String.valueOf(difference);
		print += " (ms)";
		TextView myTextField = (TextView)findViewById(R.id.tv1);
		myTextField.setText(print);
	}
	
	public String convertInputStreamToString(InputStream in) 
	{        
	        BufferedReader br;  
	        StringBuffer outString = new StringBuffer();
	        br = new BufferedReader(new InputStreamReader(in));  
	        try{
		        String read = br.readLine();
		        
		        while(read != null)
		        {
		            outString.append(read);
		            read = br.readLine();
		        }
	        }
	        catch(IOException e)
	        {
	        	Log.d("oclDebug",e.toString());
	        }
	        
	        return outString.toString();     
	}
	
	public void initArrays(int[] arrayA, int[] arrayB, int[] arrayC, int size)
	{
		for(int i=0 ; i<size ; ++i)
		{
			arrayA[i] = i;
			arrayB[i] = size - i;
			arrayC[i] = 0;
		}
	}
	
	public void calcArrays(int[] arrayA, int[] arrayB, int[] arrayC, int size)
	{
		for(int i=0 ; i<size ; ++i)
		{
			arrayC[i] = arrayB[i] + arrayA[i];
		}
	}
	
	public native void  addArraysViaOpenCL(int[] arrayA, int[] arrayB, int[] arrayC, String kernelCode, float[] runTime);
	
	static {
		System.loadLibrary("OpenCLFirstApp");
	}
}

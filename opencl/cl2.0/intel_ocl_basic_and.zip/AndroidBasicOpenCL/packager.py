import os
import zipfile
import re

filesToAdd = [
    r'\.[\\/]((res)|(assets)|(jni)|(src))[\\/].*',
    r'\.[\\/]\.classpath',
    r'\.[\\/]\.project',
    r'\.[\\/]AndroidManifest\.xml',
    r'\.[\\/]ic_launcher-web\.png',
    r'\.[\\/]proguard-project\.txt',
    r'\.[\\/]project\.properties',
    r'\.[\\/]README\.TXT',
    r'\.[\\/]user_guide\.pdf',
    r'\.[\\/]bin[\\/]AndroidBasicOpenCL\.apk'
]

def isAccepted (fileName):
    for pattern in filesToAdd:
        if re.match(pattern, fileName):
            return True
    return False

def zipdir(path, zip):
    for root, dirs, files in os.walk(path):
        for file in files:
            fileName = os.path.join(root, file)
            print 'Discovered file ' + fileName
            if isAccepted(fileName):
                print 'Added'
                zip.write(fileName)
            else:
                print 'Skipped'

if __name__ == '__main__':
    zipf = zipfile.ZipFile('AndroidBasicOpenCL.zip', 'w')
    zipdir('.', zipf)
    zipf.close()

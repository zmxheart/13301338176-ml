from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from fcn.models.fcn8s import FCN8s
from fcn.models.fcn16s import FCN16s
from fcn.models.fcn32s import FCN32s
from fcn.models.vgg16 import VGG16

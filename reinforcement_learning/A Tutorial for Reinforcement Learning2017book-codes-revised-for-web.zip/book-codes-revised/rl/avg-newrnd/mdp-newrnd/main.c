# include <stdio.h>
# include <stdlib.h> 
# include <math.h>
# include "global.h"
# include "typedefs.h"
# include "fun_prots.h"
# include "fun_list.h"
main()
{

simulator_mc();

return;
}

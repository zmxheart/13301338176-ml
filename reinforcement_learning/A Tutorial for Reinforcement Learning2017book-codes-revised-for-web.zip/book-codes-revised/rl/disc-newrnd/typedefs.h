

typedef struct {
double Q[NS][NA];
int iter;
int old_action;
int old_state;
int current_state;
double rimm;
}statistics;


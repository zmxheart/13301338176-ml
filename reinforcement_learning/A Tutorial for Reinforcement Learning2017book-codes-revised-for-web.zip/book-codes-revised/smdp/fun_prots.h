void pias(double [NA][NS][NS],double [NA][NS][NS],double [NA][NS][NS]);   
void solver(double [NS][NS+1],double [NS]);     

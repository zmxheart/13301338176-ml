void rvia(double [NS][NS][NA],double [NS][NS][NA],double); 
void via(double [NS][NS][NA],double [NS][NS][NA],double); 

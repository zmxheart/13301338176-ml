void vi(double [NS][NS][NA],double [NS][NS][NA],double,double);
void gsvi(double [NS][NS][NA],double [NS][NS][NA],double,double);
void rvi(double [NS][NS][NA],double [NS][NS][NA],double,double);

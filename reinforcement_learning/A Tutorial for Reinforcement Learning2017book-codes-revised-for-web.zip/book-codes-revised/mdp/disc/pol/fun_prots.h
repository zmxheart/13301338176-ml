void pid(double [NA][NS][NS],double [NA][NS][NS],double);   
void solver(double [NS][NS+1],double [NS]);     

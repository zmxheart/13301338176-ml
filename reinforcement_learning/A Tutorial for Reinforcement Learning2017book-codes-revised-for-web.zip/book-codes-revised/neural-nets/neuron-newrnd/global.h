# define NO_INPUTS  2 /* number of input nodes */
# define DATA_SIZE 10 /* number of training examples in the batch */
int ITERMAX=700;



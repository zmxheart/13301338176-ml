
# include "unifrnd.c"
# include "init_net.c"
# include "simu_net.c"
# include "neuron.c"
# include "reader.c"
# include "evaluator.c"


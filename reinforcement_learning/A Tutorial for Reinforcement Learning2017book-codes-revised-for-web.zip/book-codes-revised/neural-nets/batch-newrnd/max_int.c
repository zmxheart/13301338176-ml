int max_int(int ,int );
int max_int(int a,int b)
{
if(a>b)
{
return(a);
}
else
{
return(b);
}
}

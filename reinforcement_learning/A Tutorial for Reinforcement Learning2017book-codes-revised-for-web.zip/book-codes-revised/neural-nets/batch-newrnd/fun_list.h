
# include "unifrnd.c"
# include "compute_sigmoid.c"
# include "init_net.c"
# include "simu_net.c"
# include "backprop_batch.c"
# include "reader.c"
# include "evaluator.c"


      COMMON/var/actual(10),first(10),last(10),park_station(10),
     1           sload(20),srate(20),cload(20),in_motion(10),tss,tlast,
     2           old(10),map(30),old2(10),num_calls,old_cc(10,2,10),
     3           new_cc(10,2,10),old_button(2,10),new_button(2,10),
     4           first_event,previous_first(10)
      INTEGER actual,first,last,park_station,old,old2,map,num_calls,
     .        previous_first
      REAL    in_motion,tss,tlast
      REAL    sload,cload,srate
      LOGICAL old_cc,new_cc,old_button,new_button,first_event

C moved this data stmt to one place in downer.for  (Bob Crites 1/12/94) 
C     DATA    first_event/.TRUE./




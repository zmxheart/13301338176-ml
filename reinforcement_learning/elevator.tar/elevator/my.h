      COMMON /mycom/ cur_dir(10),cur_flr(10),tot_flrs,             
     1tot_cars,arr_int(40,25),entrance_time,exit_time,
     2flr_time,ground_flr,stop_time,max_wait,
     4car_calls(10,2,50),hall_calls(10,2,50),park_floor(10),
     5debug,capacity,nalg,graphics,print,start,
     6buttons(2,40),num_sys,max_sys,old_calls(10,2,50),x(25),
     7last_screen(80,25),new_screen(80,25),last_mode(80,25),
     8new_mode(80,25),gmode,bload(10),door_open(8),state(10),
     9screen_width,max_interval,down(10,25),stationary_load
	COMMON /asif_noc/flag_carfull,floor_carfull(4)
	COMMON /ASIF_STATS/ car_flag(10,3)                         
	COMMON/asif__global/glo_var(15),start_event
        COMMON/state_type/accel,decel,loading,moving,parking,stopped,
     .     awake,turning


      CHARACTER last_screen,new_screen 
      INTEGER cur_dir,cur_flr,tot_flrs,tot_cars,park_floor,capacity
      INTEGER accel,decel,loading,moving,parking,stopped,turning,awake,state
      INTEGER nalg,start,num_sys,max_sys,ground_flr
      INTEGER last_mode,new_mode,gmode,screen_width,max_wait    
      LOGICAL door_open,debug,graphics,print,stationary_load,start_event
      REAL    arr_int,bload,entrance_time,exit_time,flr_time,max_interval
      REAL    x,stop_time,car_calls,hall_calls,buttons,old_calls,down
	INTEGER  flag_carfull,floor_carfull
	real car_flag,glo_var

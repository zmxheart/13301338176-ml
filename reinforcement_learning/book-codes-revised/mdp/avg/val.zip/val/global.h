double SMALL=-100000;
# define NS 2
# define NA 2

double estimator(double x_current[])
{

return(((x_current[0] - 4) * (x_current[0] - 4)) + 
((x_current[1] - 2) * (x_current[1] - 2)));


}

#define NO_OF_PARAMETERS 2

#include <stdio.h>
#include<stdlib.h>
#include <math.h>

#include "fun_prots.h"
#include "fun_list.h"

main()
{
double x_current[NO_OF_PARAMETERS],A,itermax;


	
        
        itermax=25; /* number of iterations of algm to run */
        A = 1; /* step-size parameter used in Spall's step size */
        
        /* initialize the decision variables to arbitrary values */
        x_current[0] = 8.0;
        x_current[1] = 7.0;
        
        sp(x_current,itermax,A);
	
        
        

}


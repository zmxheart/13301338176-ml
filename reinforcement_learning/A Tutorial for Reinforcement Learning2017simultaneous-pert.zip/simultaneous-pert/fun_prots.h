/**********fun_prots.h********/

double estimator(double []);
double unifrnd(double, double);
double sp(double [],double,double);

double sp(double x_current[],double itermax,double A)
{
/* uses the standard simultaneous perturbation algorithm of Spall */

double ran_no, h[NO_OF_PARAMETERS], multiplier, step_size,  F_plus, F_minus, 
x_increased[NO_OF_PARAMETERS], x_decreased[NO_OF_PARAMETERS], partial_deriv[NO_OF_PARAMETERS], result_current, iteration;
long seed;
int binom[NO_OF_PARAMETERS], i;
	
        iteration = 1;
        seed = 10;
        srand48(seed);
        /* first evaluate the function at the initial value of the decision variables, x_current */
        result_current = estimator(x_current);
        printf("The function value at the start = %lf\n",result_current);
while(iteration<itermax)
        {
                multiplier = 1/sqrt(iteration);
                step_size = (A/iteration);

                for(i=0; i<NO_OF_PARAMETERS; i++)
                {
                        ran_no = unifrnd(0, 1);	
                        /* determine values for the binomially distributed random variable */
			if(ran_no>0.5)
                        {
                        binom[i] = 1;
                        }
			else
                        {
                        binom[i] =-1;
                        }
                        h[i] = binom[i] * multiplier;

                        x_increased[i] = x_current[i] + h[i];
                        x_decreased[i] = x_current[i] - h[i];
                }

                F_plus = estimator(x_increased);
                F_minus = estimator(x_decreased);

                for(i=0; i<NO_OF_PARAMETERS; i++)
                {
                partial_deriv[i] = (F_plus - F_minus)/(2*h[i]);		
                x_current[i] = x_current[i] - (step_size*partial_deriv[i]);
                }

                result_current = estimator(x_current);
                printf("The function value in iteration = %lf is %lf\n",iteration,result_current);

                iteration++;
                
        }

        for(i=0;i<NO_OF_PARAMETERS;i=i+1)
        {
        printf("x[%d]=%lf\n",i,x_current[i]);
        }
        printf("The optimum function value = %lf \n", result_current);
        printf("The number of iterations run = %lf \n", iteration);


}

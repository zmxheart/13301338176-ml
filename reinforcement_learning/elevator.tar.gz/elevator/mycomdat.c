/* mycomdat.f -- translated by f2c (version 19950918).
   You must link the resulting object file with the libraries:
	-lF77 -lI77 -lm -lc   (in that order)
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    integer cur_dir__[10], cur_flr__[10], tot_flrs__, tot_cars__;
    real arr_int__[1000]	/* was [40][25] */, entrance_time__, 
	    exit_time__, flr_time__;
    integer ground_flr__;
    real stop_time__;
    integer max_wait__;
    real car_calls__[1000]	/* was [10][2][50] */, hall_calls__[1000]	
	    /* was [10][2][50] */;
    integer park_floor__[10];
    logical debug;
    integer capacity, nalg;
    logical graphics, print;
    integer start;
    real buttons[80]	/* was [2][40] */;
    integer num_sys__, max_sys__;
    real old_calls__[1000]	/* was [10][2][50] */, x[25];
    char last_screen__[2000]	/* was [80][25] */, new_screen__[2000]	/* 
	    was [80][25] */;
    integer last_mode__[2000]	/* was [80][25] */, new_mode__[2000]	/* 
	    was [80][25] */, gmode;
    real bload[10];
    logical door_open__[8];
    integer state[10], screen_width__;
    real max_interval__, down[250]	/* was [10][25] */;
    logical stationary_load__;
} mycom_;

#define mycom_1 mycom_

struct {
    integer flag_carfull__, floor_carfull__[4];
} asif_noc__;

#define asif_noc__1 asif_noc__

struct {
    real car_flag__[30]	/* was [10][3] */;
} asif_stats__;

#define asif_stats__1 asif_stats__

struct {
    real glo_var__[15];
    logical start_event__;
} asif__global__;

#define asif__global__1 asif__global__

struct state_type__1_ {
    integer accel, decel, loading, moving, parking, stopped, awake, turning;
};

#define state_type__1 (*(struct state_type__1_ *) &state_type__)

/* Initialized data */

struct {
    integer e_1[8];
    } state_type__ = { 1, 2, 3, 4, 5, 6, 7, 8 };



